"use client";

import { ArrowRightOutlined } from "@ant-design/icons";
import { Button, Card, Col, Flex, Row, Space, Typography, theme } from "antd";
import Link from "next/link";
import { CodeBlock } from "./CodeBlock";
import { TerminalGif } from "./FeatureDemos";
import { PageStack } from "@/components/ui/PageStack";
import { Section } from "@/components/ui/Section";
import { site } from "@/lib/site";
import { track } from "@/lib/analytics";
import { audiences, cliFeature, type Audience } from "@/lib/audiences";

function AudienceCard({ audience }: { audience: Audience }) {
  const { token } = theme.useToken();
  return (
    <Card id={audience.id} style={{ height: "100%" }}>
      <Flex
        vertical
        gap={token.marginXS}
        align="flex-start"
        style={{ height: "100%" }}
      >
        <Typography.Title
          level={3}
          style={{ margin: 0, fontSize: token.fontSizeHeading4 }}
        >
          {audience.title}
        </Typography.Title>
        <Typography.Paragraph type="secondary" style={{ margin: 0 }}>
          {audience.summary}
        </Typography.Paragraph>
        <Link
          href={audience.cta.href}
          style={{
            marginBlockStart: "auto",
            paddingBlockStart: token.paddingXS,
          }}
        >
          {audience.cta.label} <ArrowRightOutlined aria-hidden="true" />
        </Link>
      </Flex>
    </Card>
  );
}

export function HomeContent() {
  const { token } = theme.useToken();
  return (
    <PageStack>
      <Row gutter={[token.marginXL, token.marginXL]} align="middle">
        <Col xs={24} lg={11}>
          <Section
            id="inicio"
            level={1}
            title="TISS aberto para quem envia e para quem recebe"
            description="Valide, gere e audite TISS offline. Simule a operadora, consulte dados abertos da ANS e conecte agentes por MCP."
            extra={
              <Space wrap>
                <Button type="primary" size="large" href="/playground">
                  Experimentar playground
                </Button>
                <Button size="large" href={site.docsUrl}>
                  Documentação
                </Button>
              </Space>
            }
          />
        </Col>
        <Col xs={24} lg={13}>
          <TerminalGif item={cliFeature} priority />
        </Col>
      </Row>

      <Section id="para-quem-e" title="Para quem é">
        <Row gutter={[token.margin, token.margin]}>
          {audiences.map((audience) => (
            <Col key={audience.id} xs={24} sm={12} lg={6}>
              <AudienceCard audience={audience} />
            </Col>
          ))}
        </Row>
      </Section>

      <Section
        id="comece"
        title="Comece agora"
        extra={
          <Link
            href={site.github}
            onClick={() => track("tiss_cta_github", { local: "home" })}
          >
            Código no GitHub <ArrowRightOutlined aria-hidden="true" />
          </Link>
        }
      >
        <Row gutter={[token.margin, token.margin]}>
          <Col xs={24} md={8}>
            <Card title="Biblioteca Python">
              <CodeBlock code={site.installCommand} />
            </Card>
          </Col>
          <Col xs={24} md={8}>
            <Card title="MCP local">
              <Space direction="vertical" size={token.marginXS} style={{ width: "100%" }}>
                <CodeBlock code={site.mcpLocalCommand} />
                <Typography.Text type="secondary">
                  Roda offline: as guias não saem da máquina.
                </Typography.Text>
                <Typography.Text
                  type="secondary"
                  style={{ fontSize: token.fontSizeSM, wordBreak: "break-word" }}
                >
                  Remoto: https://tiss-api.voa.health/mcp
                </Typography.Text>
              </Space>
            </Card>
          </Col>
          <Col xs={24} md={8}>
            <Card title="GitHub Action">
              <CodeBlock code={site.actionSnippet} />
            </Card>
          </Col>
        </Row>
      </Section>
    </PageStack>
  );
}
