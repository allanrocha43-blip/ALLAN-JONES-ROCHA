# MCP

O endpoint remoto usa Streamable HTTP: `https://tiss-api.voa.health/mcp`.
Sem chave, estão disponíveis apenas as ferramentas `tiss_sandbox_*`. Para as
demais, envie `Authorization: Bearer <chave>` com a chave `sk_voa_` da
organização, que vale para os produtos da Voa, criada no painel.
Para autorizações SP/SADT, use `tiss_autorizacao_build`,
`tiss_autorizacao_parse`, `tiss_autorizacao_check` e `tiss_sandbox_autorizacao`.
Para valores unitários de referência D-TISS da ANS por TUSS, use `tiss_referencia`;
preços contratados ou glosas específicas ficam nas ferramentas de operadoras.

## Exemplos de chamadas

Validar XML:

```json
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "tools/call",
  "params": {
    "name": "tiss_validate",
    "arguments": {"xml": "<mensagem>…</mensagem>"}
  }
}
```

Validar lote e aplicar patch:

```json
{
  "jsonrpc": "2.0",
  "id": 2,
  "method": "tools/call",
  "params": {
    "name": "tiss_validate",
    "arguments": {"lote": {}}
  }
}
```

Passe o lote e o relatório retornado à ferramenta `tiss_apply_fixes`, depois
revalide com `tiss_validate`. Consulte o esquema do lote em
`tiss://schemas/lote`.

## Clientes

Servidor local em stdio:

```sh
claude mcp add tiss -- uvx --from "tiss[mcp]" tiss mcp
```

Claude Code:

```sh
claude mcp add --transport http tiss https://tiss-api.voa.health/mcp
```

Codex (`~/.codex/config.toml`):

```toml
[mcp_servers.tiss]
url = "https://tiss-api.voa.health/mcp"
```

Cursor (`mcp.json`):

```json
{
  "mcpServers": {
    "tiss": {
      "url": "https://tiss-api.voa.health/mcp"
    }
  }
}
```
